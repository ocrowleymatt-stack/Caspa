import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { ToastProvider } from './components/Toast';
import Dashboard from './pages/Dashboard';
import ProjectOverview from './pages/ProjectOverview';
import ChapterEditor from './pages/ChapterEditor';
import Characters from './pages/Characters';
import PlotBoard from './pages/PlotBoard';
import Research from './pages/Research';
import ShowFactory from './pages/ShowFactory';
import MusicLab from './pages/MusicLab';
import Production from './pages/Production';
import ShowInABox from './pages/ShowInABox';
import Publish from './pages/Publish';
import Settings from './pages/Settings';

export default function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Dashboard />} />
            <Route path="projects/:id" element={<ProjectOverview />} />
            <Route path="projects/:id/characters" element={<Characters />} />
            <Route path="projects/:id/plot" element={<PlotBoard />} />
            <Route path="projects/:id/research" element={<Research />} />
            <Route path="show-factory" element={<ShowFactory />} />
            <Route path="music-lab" element={<MusicLab />} />
            <Route path="production" element={<Production />} />
            <Route path="show-in-a-box" element={<ShowInABox />} />
            <Route path="publish" element={<Publish />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          <Route path="projects/:id/chapters/:chapterId" element={<ChapterEditor />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  );
}
