# CASPA Studio

CASPA Studio (Creative Authoring & Show Production Application) is a modular Node.js backend for novel writing, AI-assisted drafting, music composition briefs, show packaging, publishing exports, and commercial readiness tooling.

## Quick start

```bash
npm install
cp .env.example .env
npm run dev
```

The API listens on `http://localhost:3000`. Verify with:

```bash
curl http://localhost:3000/health
```

## Docker quick start

```bash
docker-compose up
```

This starts CASPA and a local Ollama instance. Data, backups, exports, and the UI mount from the project directory.

## Connecting a UI

The backend and UI are decoupled. Drop any static site into `/public`:

```bash
rm -rf public/*
cd my-new-ui && npm run build
cp -r dist/* ../public/
```

No server restart is required. If `public/index.html` is missing, API routes still work; unknown non-API paths return a JSON 404.

## API base URL

- **Base URL:** `http://localhost:3000`
- **Health:** `GET /health` → `{"status":"ok","version":"1.0.0","timestamp":"..."}`

## Modules

| Module | Base routes |
|--------|-------------|
| Storage | `/api/storage/*` |
| Manuscript | `/api/projects/*`, `/api/chapters/*`, `/api/characters/*`, `/api/research/*`, `/api/plot/*` |
| AI Assistant | `/api/assist/*`, `/api/ai/*` |
| Show Factory | `/api/show-factory/*` |
| Music Lab | `/api/music-lab/*` |
| Orchestra (jobs) | `/api/jobs/*` |
| Publishing | `/api/publish/*` |
| Show In A Box | `/api/show-box/*` |

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | HTTP listen port |
| `DATA_DIR` | `./data` | JSON data store directory |
| `OLLAMA_URL` | `http://localhost:11434` | Local Ollama API URL |
| `OLLAMA_MODEL` | `llama3.2` | Default Ollama model |
| `GEMINI_API_KEY` | — | Google Gemini API key (optional) |
| `OPENAI_API_KEY` | — | OpenAI API key (optional) |
| `ANTHROPIC_API_KEY` | — | Anthropic API key (optional) |
| `GROK_API_KEY` | — | xAI Grok API key (optional) |
| `DROPBOX_TOKEN` | — | Dropbox sync token (optional) |
| `BACKUP_DIR` | `./backups` | Backup output directory |
| `LOG_LEVEL` | `info` | Log level: `debug`, `info`, `warn`, `error` |

## Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start with hot reload (`tsx watch server.ts`) |
| `npm run build` | Compile TypeScript to `dist/` |
| `npm start` | Run compiled server (`node dist/server.js`) |
| `npm run lint` | Typecheck without emitting (`tsc --noEmit`) |
