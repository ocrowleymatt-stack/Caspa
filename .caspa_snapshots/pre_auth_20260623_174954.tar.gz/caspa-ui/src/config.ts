// Empty string = same-origin (UI served by Express on the same port).
export const API_BASE = import.meta.env.VITE_API_URL ?? '';
