import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { JobStatus, Project } from '../types';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppState {
  activeProjectId: string | null;
  setActiveProjectId: (id: string | null) => void;

  sidebarCollapsed: boolean;
  toggleSidebar: () => void;

  aiPanelOpen: boolean;
  setAiPanelOpen: (open: boolean) => void;
  toggleAiPanel: () => void;

  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  jobs: JobStatus[];
  setJobs: (jobs: JobStatus[]) => void;
  upsertJob: (job: JobStatus) => void;

  toasts: ToastMessage[];
  addToast: (type: ToastMessage['type'], message: string) => void;
  removeToast: (id: string) => void;

  projects: Project[];
  setProjects: (projects: Project[]) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      activeProjectId: null,
      setActiveProjectId: (id) => set({ activeProjectId: id }),

      sidebarCollapsed: false,
      toggleSidebar: () => set({ sidebarCollapsed: !get().sidebarCollapsed }),

      aiPanelOpen: false,
      setAiPanelOpen: (open) => set({ aiPanelOpen: open }),
      toggleAiPanel: () => set({ aiPanelOpen: !get().aiPanelOpen }),

      commandPaletteOpen: false,
      setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),

      jobs: [],
      setJobs: (jobs) => set({ jobs }),
      upsertJob: (job) =>
        set((state) => {
          const idx = state.jobs.findIndex((j) => j.id === job.id);
          if (idx >= 0) {
            const next = [...state.jobs];
            next[idx] = { ...next[idx], ...job };
            return { jobs: next };
          }
          return { jobs: [job, ...state.jobs] };
        }),

      toasts: [],
      addToast: (type, message) => {
        const id = crypto.randomUUID();
        set((state) => ({ toasts: [...state.toasts, { id, type, message }] }));
        setTimeout(() => get().removeToast(id), 4000);
      },
      removeToast: (id) =>
        set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),

      projects: [],
      setProjects: (projects) => set({ projects }),
    }),
    {
      name: 'caspa-ui',
      partialize: (state) => ({
        activeProjectId: state.activeProjectId,
        sidebarCollapsed: state.sidebarCollapsed,
        aiPanelOpen: state.aiPanelOpen,
      }),
    },
  ),
);
