import { NavLink, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  BookOpen,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  Clapperboard,
  Gem,
  Map,
  MapPin,
  BookMarked,
  Mic,
  Music,
  Package,
  Paintbrush,
  PenLine,
  Settings,
  ShieldCheck,
  Sparkles,
  Star,
  Theater,
  Trophy,
  Upload,
  Users,
  Palette,
} from 'lucide-react';
import { listProjects } from '../api/projects';
import { useAppStore } from '../store';
import { cn } from '../lib/utils';

const navItems = [
  { to: '/', label: 'Projects', icon: BookOpen, end: true },
  { to: '/show-factory', label: 'Show Factory', icon: Theater },
  { to: '/music-lab', label: 'Music Lab', icon: Music },
  { to: '/production', label: 'Production', icon: Clapperboard },
  { to: '/show-in-a-box', label: 'Show In A Box', icon: Package },
  { to: '/publish', label: 'Publish', icon: Upload },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const elevationItems = [
  { to: '/wonder', label: 'Wonder', icon: Sparkles },
  { to: '/quality', label: 'Quality', icon: ShieldCheck },
  { to: '/taste', label: 'Taste', icon: Palette },
  { to: '/audience', label: 'Audience', icon: Users },
  { to: '/showstopper', label: 'Showstopper', icon: Star },
  { to: '/rehearsal', label: 'Rehearsal', icon: Mic },
  { to: '/producer', label: 'Producer', icon: Briefcase },
  { to: '/localise', label: 'Localise', icon: MapPin },
  { to: '/visuals', label: 'Visuals', icon: Paintbrush },
  { to: '/awards', label: 'Awards', icon: Trophy },
  { to: '/gold', label: 'Gold', icon: Gem },
];

export function Sidebar() {
  const collapsed = useAppStore((s) => s.sidebarCollapsed);
  const toggle = useAppStore((s) => s.toggleSidebar);
  const activeProjectId = useAppStore((s) => s.activeProjectId);
  const setActiveProjectId = useAppStore((s) => s.setActiveProjectId);
  const navigate = useNavigate();

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: listProjects,
  });

  return (
    <aside
      className={cn(
        'flex h-full flex-col border-r border-white/10 bg-surface/80 backdrop-blur-sm transition-all duration-200',
        collapsed ? 'w-16' : 'w-60',
      )}
    >
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-4">
        {!collapsed && (
          <div>
            <h1 className="text-lg font-bold tracking-tight">
              <span className="text-accent">CASPA</span> Studio
            </h1>
            <p className="text-xs text-muted">Creative Suite</p>
          </div>
        )}
        <button type="button" onClick={toggle} className="btn-ghost p-1.5">
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {!collapsed && (
        <div className="border-b border-white/10 p-3">
          <label className="label">Active Project</label>
          <select
            value={activeProjectId ?? ''}
            onChange={(e) => {
              const id = e.target.value || null;
              setActiveProjectId(id);
              if (id) navigate(`/projects/${id}`);
            }}
            className="input text-xs"
          >
            <option value="">Select project...</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title}
              </option>
            ))}
          </select>
        </div>
      )}

      <nav className="flex-1 overflow-y-auto p-2 space-y-1">
        {navItems.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors',
                isActive
                  ? 'bg-accent/15 text-accent font-medium'
                  : 'text-muted hover:bg-white/5 hover:text-foreground',
                collapsed && 'justify-center px-2',
              )
            }
            title={label}
          >
            <Icon className="h-4 w-4 shrink-0" />
            {!collapsed && label}
          </NavLink>
        ))}

        {!collapsed && (
          <div className="pt-4 mt-2">
            <p className="px-3 mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              ✨ Elevation
            </p>
            {elevationItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                    isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
                  )
                }
              >
                <Icon className="h-4 w-4" /> {label}
              </NavLink>
            ))}
          </div>
        )}

        {collapsed && elevationItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                'flex items-center justify-center rounded-lg px-2 py-2.5 text-sm transition-colors',
                isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
              )
            }
            title={label}
          >
            <Icon className="h-4 w-4 shrink-0" />
          </NavLink>
        ))}

        {activeProjectId && !collapsed && (
          <div className="pt-4 mt-4 border-t border-white/10">
            <p className="px-3 mb-2 text-xs font-medium uppercase tracking-wide text-muted">
              Manuscript
            </p>
            <NavLink
              to={`/projects/${activeProjectId}`}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                  isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
                )
              }
            >
              <PenLine className="h-4 w-4" /> Overview
            </NavLink>
            <NavLink
              to={`/projects/${activeProjectId}/characters`}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                  isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
                )
              }
            >
              <Users className="h-4 w-4" /> Characters
            </NavLink>
            <NavLink
              to={`/projects/${activeProjectId}/plot`}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                  isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
                )
              }
            >
              <Map className="h-4 w-4" /> Plot Board
            </NavLink>
            <NavLink
              to={`/projects/${activeProjectId}/research`}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                  isActive ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-white/5',
                )
              }
            >
              <BookMarked className="h-4 w-4" /> Research
            </NavLink>
          </div>
        )}
      </nav>

      {!collapsed && (
        <div className="border-t border-white/10 p-3">
          <button
            type="button"
            onClick={() => useAppStore.getState().setCommandPaletteOpen(true)}
            className="flex w-full items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-muted hover:bg-white/5"
          >
            <Sparkles className="h-3 w-3" />
            <span className="flex-1 text-left">Command palette</span>
            <kbd className="rounded border border-white/10 px-1">⌘K</kbd>
          </button>
        </div>
      )}
    </aside>
  );
}
