import { apiCall } from './client';
import type { GoldReport } from '../types';

export async function runGoldPipeline(projectId: string) {
  return apiCall<GoldReport>(`/api/gold/run/${projectId}`, { method: 'POST' });
}

export async function getGoldReport(projectId: string) {
  return apiCall<GoldReport | null>(`/api/gold/report/${projectId}`);
}
