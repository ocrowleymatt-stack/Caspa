import fs from 'fs/promises';
import path from 'path';
import { nanoid } from 'nanoid';
import { getConfig } from './config';

async function ensureDataDir(): Promise<string> {
  const { dataDir } = getConfig();
  await fs.mkdir(dataDir, { recursive: true });
  return dataDir;
}

function collectionPath(dataDir: string, name: string): string {
  return path.join(dataDir, `${name}.json`);
}

export async function readCollection<T>(name: string): Promise<T[]> {
  const dataDir = await ensureDataDir();
  const filePath = collectionPath(dataDir, name);

  try {
    const content = await fs.readFile(filePath, 'utf-8');
    return JSON.parse(content) as T[];
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      return [];
    }

    throw error;
  }
}

export async function writeCollection<T>(name: string, data: T[]): Promise<void> {
  const dataDir = await ensureDataDir();
  const filePath = collectionPath(dataDir, name);
  const tmpPath = `${filePath}.tmp`;

  await fs.writeFile(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  await fs.rename(tmpPath, filePath);
}

export async function findById<T extends { id: string }>(
  name: string,
  id: string,
): Promise<T | null> {
  const items = await readCollection<T>(name);
  return items.find((item) => item.id === id) ?? null;
}

export async function upsert<T extends { id: string }>(
  name: string,
  item: T,
): Promise<T> {
  const items = await readCollection<T>(name);
  const index = items.findIndex((existing) => existing.id === item.id);

  if (index === -1) {
    items.push(item);
  } else {
    items[index] = item;
  }

  await writeCollection(name, items);
  return item;
}

export async function deleteById(name: string, id: string): Promise<boolean> {
  const items = await readCollection<{ id: string }>(name);
  const nextItems = items.filter((item) => item.id !== id);

  if (nextItems.length === items.length) {
    return false;
  }

  await writeCollection(name, nextItems);
  return true;
}

export function generateId(): string {
  return nanoid(12);
}
