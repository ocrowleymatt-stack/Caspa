import type { CASPAConfig } from './types';

const LOG_LEVELS: CASPAConfig['logLevel'][] = ['debug', 'info', 'warn', 'error'];

function parsePort(value: string | undefined, fallback: number): number {
  if (value === undefined || value === '') {
    return fallback;
  }

  const parsed = Number.parseInt(value, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
}

function parseLogLevel(value: string | undefined): CASPAConfig['logLevel'] {
  if (value && LOG_LEVELS.includes(value as CASPAConfig['logLevel'])) {
    return value as CASPAConfig['logLevel'];
  }

  return 'info';
}

export function getConfig(): CASPAConfig {
  return {
    port: parsePort(process.env.PORT, 3000),
    dataDir: process.env.DATA_DIR ?? './data',
    ollamaUrl: process.env.OLLAMA_URL ?? 'http://localhost:11434',
    ollamaModel: process.env.OLLAMA_MODEL ?? 'llama3.2',
    geminiApiKey: process.env.GEMINI_API_KEY,
    openaiApiKey: process.env.OPENAI_API_KEY,
    anthropicApiKey: process.env.ANTHROPIC_API_KEY,
    grokApiKey: process.env.GROK_API_KEY,
    dropboxToken: process.env.DROPBOX_TOKEN,
    backupDir: process.env.BACKUP_DIR ?? './backups',
    logLevel: parseLogLevel(process.env.LOG_LEVEL),
  };
}

export const config: CASPAConfig = getConfig();
