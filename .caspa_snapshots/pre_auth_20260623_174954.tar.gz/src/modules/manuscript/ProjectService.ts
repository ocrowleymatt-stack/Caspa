import fs from 'fs/promises';
import path from 'path';
import {
  deleteById,
  emitEvent,
  findById,
  generateId,
  getConfig,
  logger,
  readCollection,
  upsert,
  writeCollection,
  type Chapter,
  type Character,
  type PlotPoint,
  type Project,
  type ResearchNote,
} from '../../shared';

const PROJECTS = 'projects';
const CHAPTERS = 'chapters';
const CHARACTERS = 'characters';
const PLOT_POINTS = 'plot-points';
const RESEARCH_NOTES = 'research-notes';

export class NotFoundError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'NotFoundError';
  }
}

async function removeWhere<T>(
  collection: string,
  predicate: (item: T) => boolean,
): Promise<T[]> {
  const items = await readCollection<T & { id: string }>(collection);
  const removed = items.filter(predicate) as T[];
  const remaining = items.filter((item) => !predicate(item));
  await writeCollection(collection, remaining);
  return removed;
}

async function deleteChapterHistoryFiles(chapterIds: string[]): Promise<void> {
  const historyDir = path.join(getConfig().dataDir, 'history');

  await Promise.all(
    chapterIds.map(async (chapterId) => {
      try {
        await fs.unlink(path.join(historyDir, `${chapterId}.json`));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
          logger.warn(`Failed to delete chapter history for ${chapterId}: ${error}`);
        }
      }
    }),
  );
}

export class ProjectService {
  async listProjects(): Promise<Project[]> {
    return readCollection<Project>(PROJECTS);
  }

  async getProject(id: string): Promise<Project> {
    const project = await findById<Project>(PROJECTS, id);
    if (!project) {
      throw new NotFoundError(`Project not found: ${id}`);
    }
    return project;
  }

  async createProject(
    data: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'currentWordCount'>,
  ): Promise<Project> {
    const now = new Date().toISOString();
    const project: Project = {
      ...data,
      id: generateId(),
      currentWordCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    await upsert(PROJECTS, project);
    emitEvent('project:created', project);
    logger.info(`Created project: ${project.id}`);
    return project;
  }

  async updateProject(id: string, data: Partial<Project>): Promise<Project> {
    const existing = await this.getProject(id);
    const { id: _id, createdAt: _createdAt, ...updates } = data;

    const project: Project = {
      ...existing,
      ...updates,
      id: existing.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString(),
    };

    await upsert(PROJECTS, project);
    emitEvent('project:updated', project);
    return project;
  }

  async deleteProject(id: string): Promise<void> {
    await this.getProject(id);

    const chapters = await removeWhere<Chapter>(
      CHAPTERS,
      (chapter) => chapter.projectId === id,
    );
    await deleteChapterHistoryFiles(chapters.map((chapter) => chapter.id));

    await removeWhere<Character>(CHARACTERS, (character) => character.projectId === id);
    await removeWhere<PlotPoint>(PLOT_POINTS, (plot) => plot.projectId === id);
    await removeWhere<ResearchNote>(RESEARCH_NOTES, (note) => note.projectId === id);

    await deleteById(PROJECTS, id);
    emitEvent('project:deleted', { id });
    logger.info(`Deleted project and related data: ${id}`);
  }

  async recalculateWordCount(projectId: string): Promise<number> {
    const chapters = await readCollection<Chapter>(CHAPTERS);
    const total = chapters
      .filter((chapter) => chapter.projectId === projectId)
      .reduce((sum, chapter) => sum + chapter.wordCount, 0);

    const project = await this.getProject(projectId);
    if (project.currentWordCount !== total) {
      await this.updateProject(projectId, { currentWordCount: total });
    }

    return total;
  }

  async getProjectStats(projectId: string): Promise<{
    wordCount: number;
    chapterCount: number;
    characterCount: number;
    plotPointCount: number;
    noteCount: number;
  }> {
    await this.getProject(projectId);

    const [chapters, characters, plotPoints, notes] = await Promise.all([
      readCollection<Chapter>(CHAPTERS),
      readCollection<Character>(CHARACTERS),
      readCollection<PlotPoint>(PLOT_POINTS),
      readCollection<ResearchNote>(RESEARCH_NOTES),
    ]);

    const projectChapters = chapters.filter((chapter) => chapter.projectId === projectId);

    return {
      wordCount: projectChapters.reduce((sum, chapter) => sum + chapter.wordCount, 0),
      chapterCount: projectChapters.length,
      characterCount: characters.filter((character) => character.projectId === projectId).length,
      plotPointCount: plotPoints.filter((plot) => plot.projectId === projectId).length,
      noteCount: notes.filter((note) => note.projectId === projectId).length,
    };
  }
}
