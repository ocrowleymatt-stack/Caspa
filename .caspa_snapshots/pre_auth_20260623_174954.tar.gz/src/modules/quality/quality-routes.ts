import { asyncHandler, createElevationRouter, param, sendError, sendSuccess } from '../../shared/routeHelpers';
import { qualityOrchestrator } from './qualityOrchestrator';

export const qualityRouter = createElevationRouter();

qualityRouter.post(
  '/api/quality/check-text',
  asyncHandler(async (req, res) => {
    const { text } = req.body as { text?: string };
    if (!text?.trim()) {
      sendError(res, new Error('text is required'), 400);
      return;
    }
    sendSuccess(res, qualityOrchestrator.checkText(text));
  }),
);

qualityRouter.post(
  '/api/quality/check-project/:projectId',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await qualityOrchestrator.checkProject(param(req, 'projectId')));
  }),
);

qualityRouter.post(
  '/api/quality/check-show/:showPackageId',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await qualityOrchestrator.checkShow(param(req, 'showPackageId')));
  }),
);

qualityRouter.post(
  '/api/quality/check-marketing',
  asyncHandler(async (req, res) => {
    const { text } = req.body as { text?: string };
    if (!text?.trim()) {
      sendError(res, new Error('text is required'), 400);
      return;
    }
    sendSuccess(res, await qualityOrchestrator.checkMarketing(text));
  }),
);

qualityRouter.post(
  '/api/quality/final-gate/:projectId',
  asyncHandler(async (req, res) => {
    sendSuccess(res, await qualityOrchestrator.finalGate(param(req, 'projectId')));
  }),
);
