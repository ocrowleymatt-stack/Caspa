import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthGuard } from './components/AuthGuard';
import { Layout } from './components/Layout';
import { RequireAdmin } from './components/RequireAdmin';
import { ToastProvider } from './components/Toast';
import AdminUsers from './pages/AdminUsers';
import Dashboard from './pages/Dashboard';
import ProjectOverview from './pages/ProjectOverview';
import ChapterEditor from './pages/ChapterEditor';
import Characters from './pages/Characters';
import PlotBoard from './pages/PlotBoard';
import Research from './pages/Research';
import ShowFactory from './pages/ShowFactory';
import MusicLab from './pages/MusicLab';
import Production from './pages/Production';
import ShowInABox from './pages/ShowInABox';
import Publish from './pages/Publish';
import Settings from './pages/Settings';
import Wonder from './pages/Wonder';
import Quality from './pages/Quality';
import Taste from './pages/Taste';
import Audience from './pages/Audience';
import Showstopper from './pages/Showstopper';
import Rehearsal from './pages/Rehearsal';
import Producer from './pages/Producer';
import Localise from './pages/Localise';
import Visuals from './pages/Visuals';
import Awards from './pages/Awards';
import Gold from './pages/Gold';
import Login from './pages/Login';
import Register from './pages/Register';

export default function App() {
  return (
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route element={<AuthGuard />}>
            <Route element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="projects/:id" element={<ProjectOverview />} />
              <Route path="projects/:id/characters" element={<Characters />} />
              <Route path="projects/:id/plot" element={<PlotBoard />} />
              <Route path="projects/:id/research" element={<Research />} />
              <Route path="show-factory" element={<ShowFactory />} />
              <Route path="music-lab" element={<MusicLab />} />
              <Route path="production" element={<Production />} />
              <Route path="show-in-a-box" element={<ShowInABox />} />
              <Route path="publish" element={<Publish />} />
              <Route path="wonder" element={<Wonder />} />
              <Route path="quality" element={<Quality />} />
              <Route path="taste" element={<Taste />} />
              <Route path="audience" element={<Audience />} />
              <Route path="showstopper" element={<Showstopper />} />
              <Route path="rehearsal" element={<Rehearsal />} />
              <Route path="producer" element={<Producer />} />
              <Route path="localise" element={<Localise />} />
              <Route path="visuals" element={<Visuals />} />
              <Route path="awards" element={<Awards />} />
              <Route path="gold" element={<Gold />} />
              <Route path="settings" element={<Settings />} />
              <Route element={<RequireAdmin />}>
                <Route path="admin/users" element={<AdminUsers />} />
              </Route>
            </Route>
            <Route path="projects/:id/chapters/:chapterId" element={<ChapterEditor />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  );
}
